Name - Aditya Bist
Section - A
ID - abist

--------------------------------------------------------------------------------
                          Pysics
--------------------------------------------------------------------------------

Modules used = pygame, math, pygame.mixer

pygame download link - http://www.pygame.org/download.shtml

Nothing else is required to run the program.

---------------------------------------------------------------------------------

Pysics is a physics based game where you physics to move a ball to a destination.

Create squares or circles by clicking and dragging the mouse on your screen to
determine size and mass. The bigger the size of the shape, more the mass of the 
shape. Draw the shapes such that they collide with the blue ball to steer it 
to the star.

The instructions are in the game.

---------------------------------------------------------------------------------